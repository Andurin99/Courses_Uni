#include<iostream>
#include <vector>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

//*******************************************��ط��Ŷ���**********************************//

char operater_first[7] = { '=','>','<','+','-','*','/' };//������ŵĵ�һ������,<=��>=��==��++��--Ϊ˫���������

char bound_symbol[10] = { ',',';','(',')','[',']','{','}',':','#' };//���޷�

string keywords[20] = { "include","const","static","if","else","for","while","int","float","main","do",
"new","void","return","char","string","continue","bool","case","then" };//�ؼ���


int Lex_error = 0;//�ʷ����������

//*******************************************���ߺ���*************************************//

bool is_letter(char a)//�жϷ����Ƿ�Ϊ��ĸ
{
    if ((a >= 'a' && a <= 'z') || (a >= 'A' && a <= 'Z'))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool is_digit(char a)//�жϷ����Ƿ�Ϊ0-9������
{
        if (a >= '0' && a <= '9')
        {
            return 1;
        }
        else
        {
            return 0;
        }
 
}

int is_operater(char a)//�жϷ����Ƿ�Ϊ�����
{
    for (int i = 0; i < 7; i++)
    {
        if (a == operater_first[i])
            return i;
    }

    return -1;
}

int is_bound_symbol(char a)//�жϷ����Ƿ�Ϊ���޷�
{
    for (int i = 0; i < 10; i++)
    {
        if (a == bound_symbol[i])
        {
            return i;
        }
    }
    return -1;
}

bool Separate_symbol(char a)//���ü�������ֽ�������з�\�ļ���ֹ���Ϳո����ָ�ÿ���ʷ���Ԫ
{
    if ((is_operater(a)!=-1)||(is_bound_symbol(a)!=-1)||a==' '||a=='\n'||a=='\0')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Keyword_Scanner(string Buffer)//�жϴʷ���Ԫ�Ƿ�Ϊ�ؼ���
{
    int i = 0;

    for (int i = 0; i < 20; i++)
    {
        if (keywords[i] == Buffer)
        {
            cout << left << setw(15) << Buffer;
            cout<< left << setw(15) << "�ؼ���" << "TOKEN="<<i+1 << endl;
            return 1;
        }
    }

    return 0;
    
}

bool Identifier_Scanner(string Buffer)//�жϴʷ���Ԫ�Ƿ�Ϊ��ʶ��
{
    string Buffer_new = "";
    int length = Buffer.size();
    Buffer_new += Buffer[0];
    int i = 1;//���ڴ洢ƫ����
    while (is_letter(Buffer[i])||Buffer[i]=='_'||is_digit(Buffer[i]))
    {
        Buffer_new = Buffer_new + Buffer[i];
        i++;

        if (i == length)
            break;
    }



    
    if (Buffer_new == Buffer)
    {
        return 1;
    }

    return 0;
}

bool Num_Scanner(string Buffer)//�жϴʷ���Ԫ�Ƿ�Ϊ����
{
    string Buffer_new = "";
    int length = Buffer.size();
    int i = 0;
    while (is_digit(Buffer[i]))
    {
        Buffer_new = Buffer_new + Buffer[i];
        i++;

        if (i == length)
            break;
    }

    if (Buffer[i] == '.')
    {
        Buffer_new = Buffer_new + Buffer[i];
        i++;

        while (is_digit(Buffer[i]))
        {
            Buffer_new= Buffer_new + Buffer[i];
            i++;

            if (i == length)
                break;
        }
    }

    else if (Buffer[i] == 'E')
    {
        Buffer_new = Buffer_new + Buffer[i];
        i++;

        if (Buffer[i] == '+' || Buffer[i] == '-')
        {
            Buffer_new = Buffer_new + Buffer[i];
            i++;
            while (is_digit(Buffer[i]))
            {
                Buffer_new = Buffer_new + Buffer[i];
                i++;

                if (i == length)
                    break;
            }
        }
        else
        {
            while (is_digit(Buffer[i]))
            {
                Buffer_new = Buffer_new + Buffer[i];
                i++;

                if (i == length)
                    break;
            }
        }
    }

    if(Buffer_new==Buffer)
    {
        return 1;
    }

    return 0;
}

//***********************************************lex����*******************************************************//
void lex(char* a)
{
    char End_file = '\0';
    int i = 0;
    char str1 = ' ';
    char str2 = '\n';


    while (a[i] != End_file)
    {
        char temp_symbol = a[i];


        if (temp_symbol == str1)//ɨ�赽����һλΪ�ո�ʱ
        {
            i++;
            continue;
        }
        else if (temp_symbol == str2)//ɨ�赽����һλΪ���з�ʱ
        {
            i++;
            continue;
        }

        if (is_operater(temp_symbol)!=-1)//ɨ�赽����һλΪ�����ʱ
        {
            if ((is_operater(temp_symbol) < 3)&&(a[i + 1] == '='))
            {
            
                switch ((is_operater(temp_symbol)))
                {
                case(0):
                {
                    cout << a[i] << left << setw(14) << a[i + 1];
                    cout << left << setw(15) << "˫���������"<<"TOKEN=22" << endl;
                    i += 2;
                    continue;
                }
                case(1):
                {
                    cout << a[i] << left << setw(14) << a[i + 1];
                    cout << left << setw(15) << "˫���������"<<"TOKEN=23" << endl;
                    i += 2;
                    continue;
                }
                case(2):
                {
                    cout << a[i] << left << setw(14) << a[i + 1];
                    cout << left << setw(15) << "˫���������"<<"TOKEN=24" << endl;
                    i += 2;
                    continue;
                }
                }
               
            }
            else if ((is_operater(temp_symbol) == 3) && (a[i + 1] == '+'))
            {
                cout<< a[i] << left << setw(14) << a[i + 1];
                cout<< left << setw(15) << "˫���������"<<"TOKEN=25" << endl;
                i += 2;
                continue;
            }
            else if((is_operater(temp_symbol) == 4) && (a[i + 1] == '-'))
            {
                cout <<  a[i]<<left << setw(14) <<  a[i + 1];
                cout<< left << setw(15) << "˫���������"<<"TOKEN=26" << endl;
                i += 2;
                continue;

            }

            switch ((is_operater(temp_symbol)))
            {
            case(0):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=27" << endl;
                i++;
                continue;
            }
            case(1):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=28" << endl;
                i++;
                continue;
            }
            case(2):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=29" << endl;
                i++;
                continue;
            }
            case(3):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=30" << endl;
                i++;
                continue;
            }
            case(4):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=31" << endl;
                i++;
                continue;
            }
            case(5):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=32" << endl;
                i++;
                continue;
            }
            case(6):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "�����������"<<"TOKEN=33" << endl;
                i++;
                continue;
            }
            }
            

        }
        else if (is_bound_symbol(temp_symbol)!=-1)//ɨ�赽����һλΪ���޷�ʱ
        {
            switch (is_bound_symbol(temp_symbol))
            {
            case(0):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=34" << endl;
                i++;
                continue;
            }
            case(1):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=35" << endl;
                i++;
                continue;

            }
            case(2):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=36" << endl;
                i++;
                continue;

            }
            case(3):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=37" << endl;
                i++;
                continue;

            }
            case(4):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=38" << endl;
                i++;
                continue;

            }
            case(5):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=39" << endl;
                i++;
                continue;

            }
            case(6):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=40" << endl;
                i++;
                continue;

            }
            case(7):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=41" << endl;
                i++;
                continue;

            }
            case(8):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=42" << endl;
                i++;
                continue;

            }
            case(9):
            {
                cout << left << setw(15) << a[i];
                cout << left << setw(15) << "���޷�"<<"TOKEN=43" << endl;
                i++;
                continue;

            }
            }
        }
        else if (is_letter(temp_symbol))//ɨ�赽����һλΪ��ĸʱ
        {
            string Buffer = "";
            while (!Separate_symbol(a[i]))
            {
                Buffer = Buffer + a[i];
                i++;
            }
            if (Keyword_Scanner(Buffer))
            {
                continue;
            }
            else if (Identifier_Scanner(Buffer))
            {
                cout << left << setw(15) << Buffer;
                cout << left << setw(15) << "��ʶ��"<<"TOKEN=21" << endl;
                continue;

            }
            else
            {
                cout << left << setw(15) << Buffer << "�ʷ�����" << endl;
                Lex_error++;
                continue;
            }
        }
        else if (is_digit(temp_symbol))//ɨ�赽����һλΪ����ʱ
        {
            string Buffer = "";
            while (!Separate_symbol(a[i]))
            {
                Buffer = Buffer + a[i];
                i++;
            }
            if (Num_Scanner(Buffer))
            {
                cout << left << setw(15) << Buffer;
                cout<< left << setw(15) << "����"<<"TOKEN=44" << endl;
                continue;
            }
           
            else
            {
                cout << left << setw(15) << Buffer << "�ʷ�����" << endl;
                Lex_error++;
                continue;
            }
        }
        else if (a[i] == '_')//ɨ�赽����һλΪ�»���ʱ
        {
            string Buffer = "";
            while (!Separate_symbol(a[i]))
            {
                Buffer = Buffer + a[i];
                i++;
            }
            if (Identifier_Scanner(Buffer))
            {
                cout << left << setw(15) << Buffer;
                cout << left << setw(15) << "��ʶ��"<<"TOKEN=21" << endl;
                continue;

            }
            else
            {
                Lex_error++;
                continue;
            }


        }
        else//�����ǣ���Ϊmini����֮����ַ�������
        {
            cout << left << setw(15) << temp_symbol;
            cout<< "�ʷ�����" << endl;
            Lex_error++;
            continue;
        }

    }



    cout << "�ʷ�������ϣ�����" << Lex_error << "���ʷ�����" << endl;

}

//**********************************************������************************************************************//

int main()
{
   
   string filename;
   cout << "��������Ҫ�ʷ��������ļ���";
   cin >> filename;

   ifstream infile(filename.c_str());
   if (!infile)
   {
   cerr << "�޷����ļ�! " << filename.c_str() << endl;
   exit(-1);
   }
   cout << endl;
   char test[1000];
   infile.getline(test, 1000, EOF);
   infile.close();
   cout << "���Գ������£�" << endl<<endl;
   cout<<test << endl;
   cout << "***************************************" << endl;
   cout <<left<<setw(15)<< "�ʷ���Ԫ" << left << setw(15) << "���" << "TOKEN" << endl;

   lex(test);
}